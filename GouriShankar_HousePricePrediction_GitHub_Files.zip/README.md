# House Price Prediction using Machine Learning

## Project Description
This Data Analytics & AI internship project predicts house prices using Linear Regression based on area (sq ft) and number of rooms.

## Technologies
Python, Pandas, NumPy, Matplotlib, Seaborn, Scikit-learn, Flask, Streamlit, Plotly and Joblib.

## Dataset
The project uses a small **synthetic dataset** created for academic demonstration.
Dataset file: `house_price.csv`

After creating your GitHub repository, put the public dataset link here:
`https://github.com/YOUR_USERNAME/house-price-prediction/blob/main/house_price.csv`

## Setup
1. Install Python 3.9+.
2. Install dependencies:
```bash
pip install -r requirements.txt
```
3. Run the notebook:
```bash
jupyter notebook GouriShankar_HousePricePrediction.ipynb
```

## Machine Learning
- Algorithm: Linear Regression
- Features: area, rooms
- Target: price
- Train/test split: 80/20
- Evaluation: R², MAE, RMSE

## Key Information
The notebook performs data inspection, visualization, model training, evaluation and an example house-price prediction.

## Dataset Note
The dataset is synthetic and contains no real personal information.
